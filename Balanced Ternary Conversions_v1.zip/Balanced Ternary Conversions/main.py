import openpyxl
import libra

print('BEGIN')

path = "E:\\VS CODE Projects\\Python\\Balanced Ternary Conversions\\test.xlsx"

my_wb = openpyxl.load_workbook(path)
my_sheet = my_wb.active
row=my_sheet.max_row + 1 #data rows start from 2


def mutateT(i,k,bi,bk,bc,c,check):
    img = libra.ter(int(my_sheet.cell(row=row,column=i).value),mode='u')
    key = libra.ter(int(my_sheet.cell(row=row,column=k).value),mode='u')
    my_sheet.cell(row=row,column=bi).value = img
    my_sheet.cell(row=row,column=bk).value = key

    # print(img,' ',key)

    if int(my_sheet.cell(row=row,column=i).value) <= 242 and int(my_sheet.cell(row=row,column=k).value) <= 242:
        my_sheet.cell(row=row,column=check).value = 'TRUE'
        my_sheet.cell(row=row,column=bc).value = libra.op(img,key,mode='u')
        my_sheet.cell(row=row,column=c).value = libra.dec(libra.op(img,key,mode='u'),mode='u')
    else:
        my_sheet.cell(row=row,column=bc).value = img
        my_sheet.cell(row=row,column=c).value = my_sheet.cell(row=row,column=i).value




for row in range(row):
    if row > 1:
        mutateT(1,4,7,10,13,16,19)
        mutateT(2,5,8,11,14,17,20)
        mutateT(3,6,9,12,15,18,21)

my_wb.save("E:\VS CODE Projects\Python\Balanced Ternary Conversions\/test.xlsx")
print(row,' rows')