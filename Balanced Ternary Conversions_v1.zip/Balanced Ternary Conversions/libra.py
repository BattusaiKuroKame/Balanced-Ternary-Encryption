print ('Initializing...')

#num = (input('Enter a number: '))

def ter(num=0,mode='b'):
    temp=''
    if num == 0:
        return '0'
    else:
        while num!=0:
            temp=((str(num%3) if (num%3)!=2 else 'T') if mode == 'b' else str(num%3)) + temp
            num=num//3 + ((0 if (num%3)!=2 else 1)) if mode == 'b' else num//3
        return temp

def dec(num='0',mode = 'b'):
    temp=0
    mul=1
    index=len(num)-1
    while index>=0:
        val=(1 if num[index]=='1' else (-1 if num[index]=='T' else 0)) if mode == 'b' else int(str(num[index]))
        temp+=val*mul
        mul=mul*3
        index+=-1
    
    return temp
    
def compare(a='0',b='0',mode='b'):
    if mode == 'b':
        if a == '0' and b=='0':
            return '0'
        if a == '0' and b=='1':
            return 'T'
        if a == '0' and b=='T':
            return '1'
        
        if a == '1' and b=='0':
            return 'T'
        if a == '1' and b=='1':
            return '1'
        if a == '1' and b=='T':
            return '0'
        
        if a == 'T' and b=='0':
            return '1'
        if a == 'T' and b=='1':
            return '0'
        if a == 'T' and b=='T':
            return 'T'
    elif mode == 'u':
        if a == '0' and b=='0':
            return '0'
        if a == '0' and b=='1':
            return '2'
        if a == '0' and b=='2':
            return '1'

        if a == '1' and b=='0':
            return '2'
        if a == '1' and b=='1':
            return '1'
        if a == '1' and b=='2':
            return '0'

        if a == '2' and b=='0':
            return '1'
        if a == '2' and b=='1':
            return '0'
        if a == '2' and b=='2':
            return '2'
    
def op(a='0',b='0',mode='b'):
    mlen=max(len(a),len(b))
    a=a.zfill(mlen)
    b=b.zfill(mlen)
    temp=''
    
    for i in range(0,mlen,1):
        # print(compare(a[i],b[i],mode=mode))
        temp = temp + compare(a[i],b[i],mode=mode)
    # print(temp)
    return temp

print(dec('11120','u'))